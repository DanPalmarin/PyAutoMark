

assignment_num = 7

Q1 = {
    "Abrakadabra" : "r\nr\nAbrak\nAbrakadab\nArkdba\nbaaar\narbadakarbA\nabdkrA\n11",
    "Hello" : "l\nl\nHello\nHel\nHlo\nel\nolleH\nolH\n5",
    "qwertyuiop" : "e\no\nqwert\nqwertyui\nqetuo\nwryip\npoiuytrewq\npiyrw\n10"
}
Q2 = {
    "Hello world" : 2,
    "Hello" : 1,
    "q w e" : 3,
    "I am the best" : 4
}
Q3 = {
    "Qwerty" : "rtyQwe",
    "Hi" : "iH",
    "Hello" : "loHel",
    "Z" : "Z",
    "asdfghj" : "ghjasdf"
}
Q4 = {
    "Hello, world!" : "world! Hello,",
    "A BCD" : "BCD A",
    "Replit R0XX0rZzz" : "R0XX0rZzz Replit",
    
}
Q5 = {
    "In the hole in the ground there lived a hobbit" : "In tobbit",
    "qwertyhasdfghzxcvb" : "qwertyzxcvb",
    "asdfghhzxcvb" : "asdfgzxcvb",
    "ahahahahaha" : "aa",
    "ahaha" : "aa"
}
Q6 = {
    "In the hole in the ground there lived a hobbit" : "In th a devil ereht dnuorg eht ni eloh ehobbit",
    "qwertyhasdfghzxcvb" : "qwertyhgfdsahzxcvb",
    "asdfghhzxcvb" : "asdfghhzxcvb"
}
Q7 = {
    "1+1=2" : "one+one=2",
    "Hello, 2345678990" : "Hello, 2345678990",
    "1" : "one"
} 
Q8 = {
    "Bilbo.Baggins@bagend.hobbiton.shire.me" : "Bilbo.Bagginsbagend.hobbiton.shire.me",
    "dfa;sdkfj;ajva;bvna'sdasdfasdglJLHJKFHLDKJFh" : "dfa;sdkfj;ajva;bvna'sdasdfasdglJLHJKFHLDKJFh",
    "@W@E@E@E@R" : "WEEER"
}
Q9 = {
    "In the hole in the ground there lived a hobbit" : "In the Hole in tHe ground tHere lived a hobbit",
    "qwertyhahsdhfghzxcvb" : "qwertyhaHsdHfghzxcvb",
    "asdfghhzxcvb" : "asdfghhzxcvb",
    "ahbhchdheha" : "ahbHcHdHeha"
}
Q10 = {
    "LUKE SKYWALKER" : "Luke\nSkywalker\nMy first name is Luke and my last name is Skywalker.",
    "Daniel Palmarin" : "Daniel\nPalmarin\nMy first name is Daniel and my last name is Palmarin.",
    "HiHiHi ByByBy" : "Hihihi\nBybyby\nMy first name is Hihihi and my last name is Bybyby."
}

Q_weight = [1,1,1,1,1,1,1,1,1,1]
Q_flexible = [1,2,3,4,5,6,7,8,9,10]
Q_all = [Q1,Q2,Q3,Q4,Q5,Q6,Q7,Q8,Q9,Q10]