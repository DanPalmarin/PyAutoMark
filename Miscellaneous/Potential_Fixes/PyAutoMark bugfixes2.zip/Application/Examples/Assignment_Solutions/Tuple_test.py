

assignment_num = 1

Q1 = "Hello"
Q2 = ("Use", "the", "Force")
Q3 = {
    (2.5,2.5) : 10.0,
    (1,2) : 7.5
}
Q4 = {
    -5 : 5.0,
    10 : 20.0
}
Q5 = {
    (3,5) : 7.5,
    (10,2) : 10.0,
    (179,1534) : 137293.0,
    (1543,57) : 43975.5
}
Q6 = 22.98
Q7 = {
    (22.00,15) : 28.08,
    (45,12.5) : 56.19
}
Q8 = {
    1.0 : (60.0, 3600.0),
    5 : (300.0, 18000.0)
}
Q9 = {
    (1,4,2) : 8.0,
    (2.0,3.0,1.0) : 1.0
}
Q10 = {
    (1,4,2) : (-0.59, -3.41)
}

Q_weight = [1,1,1,1,1,1,1,1,1,1]
Q_flexible = [1,2,10]
#Note: Don't use flexible if the desired output has multiple lines and you used \n to denote this.
#      Use the tuple format instead to accomplish this.
Q_all = [Q1,Q2,Q3,Q4,Q5,Q6,Q7,Q8,Q9,Q10]