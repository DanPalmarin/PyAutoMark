x = input()

#Don't edit the code above here!
#Write your code below:
x = float(x) + 10
print(x)