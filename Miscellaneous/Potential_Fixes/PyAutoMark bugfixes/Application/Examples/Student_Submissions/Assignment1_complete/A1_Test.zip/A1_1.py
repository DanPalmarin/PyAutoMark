a = " Hello "
print(a)