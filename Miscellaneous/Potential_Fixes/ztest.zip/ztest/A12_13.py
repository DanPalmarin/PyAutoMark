import chessmoves
print("asd")