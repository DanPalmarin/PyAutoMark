a = "Hello"
# hehehehe
while True:
    pass
print(a)