#Here's how you get input from the user:
a = input()
b = input()
#dont edit lines above
#write code below
a = float(a) + 2.5
b = float(b) * 2
print(a+b)