a = float(input())
b = float(input())
c = float(input())

root1 = (-b + (b**2 - 4*a*c)**(1/2))/2*a
root2 = (-b - (b**2 - 4*a*c)**(1/2))/2*a

print("%.2f" % root1)
print("%.2f" % root2)