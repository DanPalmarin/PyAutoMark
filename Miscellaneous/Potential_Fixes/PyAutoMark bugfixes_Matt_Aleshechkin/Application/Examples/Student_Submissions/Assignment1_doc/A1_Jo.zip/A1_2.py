time_hours = float(input())

time_minutes = time_hours*60
time_seconds = time_hours*360

print(time_minutes)
print(time_seconds)