a = float(input())
b = float(input())
c = float(input())

disc = b**2 - 4*a*c
print(disc)