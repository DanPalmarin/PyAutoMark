x = input()

#Don't edit the code above here!
#Write your code below:
x = x + 10
print(x)