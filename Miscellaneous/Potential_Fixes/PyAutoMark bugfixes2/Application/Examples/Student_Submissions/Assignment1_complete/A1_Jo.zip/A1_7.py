meal = float(input())
tip = float(input())

tax = 0.11
tip = tip/100
meal = meal + meal * tax
total = meal + meal * tip

print("%.2f" % total)