# Read the numbers b and h like this:
b = int(input())
h = int(input())

# Print the result with print()
print(b * h / 2)