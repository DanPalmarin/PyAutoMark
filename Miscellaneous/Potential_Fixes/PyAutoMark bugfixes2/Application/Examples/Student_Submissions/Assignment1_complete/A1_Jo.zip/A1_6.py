meal = 18.00
tax = 0.11
tip = 0.15

meal = meal + meal * tax
total = meal + meal * tip

# Use this if you wish to 
# force the display of 2 decimal places
#print("%.2f" % total)

print(round(total,2))