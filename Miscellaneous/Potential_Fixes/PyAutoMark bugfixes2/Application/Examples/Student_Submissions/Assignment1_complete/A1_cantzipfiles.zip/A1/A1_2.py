#Start coding below
a = "Use "
b = "the "
c = "Force"
print(a+b+c)

#Note: You could also make a 'space' variable and call it d
#Then you would have (a+d+b+d+c)