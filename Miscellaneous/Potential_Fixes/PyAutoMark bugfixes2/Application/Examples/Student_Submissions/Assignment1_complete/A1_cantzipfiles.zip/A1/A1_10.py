a = float(input())
b = float(input())
c = float(input())

root1 = (-b + (b**2 - 4*a*c)**(1/2))/2*a
root2 = (-b - (b**2 - 4*a*c)**(1/2))/2*a

r1 = "%.2f" % root1
r2 = "%.2f" % root2

print("Root 1 is: {}".format(r1))
print("Root 2 is: {}".format(r2))