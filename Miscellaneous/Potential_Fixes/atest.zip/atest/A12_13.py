import chessmoves
print()