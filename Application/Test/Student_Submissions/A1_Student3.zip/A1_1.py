var = "Hello"
print(var)

