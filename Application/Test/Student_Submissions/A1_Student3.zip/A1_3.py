var1 = float(input())
var2 = float(input())

num1 = (var1+var2)
num2 = (var2*2)
print(num1+num2)

             
