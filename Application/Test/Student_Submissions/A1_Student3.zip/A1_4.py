var = int(input())
var2 = float(var+10.0)
print(var2)
