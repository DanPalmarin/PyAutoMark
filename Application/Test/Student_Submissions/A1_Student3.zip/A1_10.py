a = float(input())
b = float(input())
c = float(input())

discriminant =(b**2-4*a*c)
squared = discriminant**(1/2)
denominator = (2*a)
positive =(-b+squared)
negative =(-b-squared)
positive2 = round(positive/denominator,2)
negative2 = round(negative/denominator,2)
print(positive2)
print(negative2)


        
