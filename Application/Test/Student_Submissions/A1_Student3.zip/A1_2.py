var = "Use"
var2 = "the"
var3 = "Force"
print(var,var2,var3)
