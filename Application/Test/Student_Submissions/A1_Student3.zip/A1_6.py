meal = 18
tax = 0.11
tip = 0.15

taxes = (meal*tax)
taxed_meal = (taxes+meal)
total_tip = (taxed_meal*tip)
taxed_tipped_meal = round(taxed_meal+total_tip,2)
print(taxed_tipped_meal)
