height = int(input())
base = int(input())

math = float(height*base/2)

print(math)
