a = float(input())
b = float(input())
c = float(input())

discriminant = (b**2-4*a*c)
print(discriminant)

