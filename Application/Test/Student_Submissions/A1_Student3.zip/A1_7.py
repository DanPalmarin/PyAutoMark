meal =  float(input())
tax = 0.11
tip = float(input())

taxes = (meal*tax)
taxed_meal = (taxes+meal)
tip_percent = (tip/100)
total_tip = (taxed_meal*tip_percent)
total_meal = round(taxed_meal+total_tip,2)
print(total_meal)
