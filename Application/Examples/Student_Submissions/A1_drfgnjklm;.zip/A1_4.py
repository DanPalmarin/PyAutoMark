import what

print("yes")