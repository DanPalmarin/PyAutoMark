f = open("./asd.txt","w")

f.write("asd")

f.close()