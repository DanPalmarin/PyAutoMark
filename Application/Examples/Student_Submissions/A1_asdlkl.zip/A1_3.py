import re

re.match()