import what

print("yes")