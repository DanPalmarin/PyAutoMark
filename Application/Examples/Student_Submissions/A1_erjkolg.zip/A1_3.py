import re

re.match()